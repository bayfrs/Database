# Perintah :
    $ pkg update && pkg upgrade
    $ pkg install git
    $ pkg install python3
    $ git clone https://github.com/RozhakXD/Qlizz
    $ cd Qlizz
    $ pip3 install -r requirements.txt
    $ python Run.py
# Update Tools :
    $ cd $HOME/Qlizz
    $ git pull
    $ python Run.py

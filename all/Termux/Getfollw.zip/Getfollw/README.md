# Getfollw
<p align="center">
  <img src="https://1.bp.blogspot.com/-8J6nXMm4Fn4/X1nN5SrLvkI/AAAAAAAAAQ0/J8TNfruwGEgiAfOKxIiRD_q3dKOGUl-XQCLcBGAsYHQ/s530/Screenshot_20200910_122015.png" width="470" height="250">
</p>
Best Tool For Increase Instagram Follower.

Via: Login

## Requirements
1. openssl
2. curl

## How to Install in Termux

`$ pkg up -y`

`$ pkg install openssl-tool`

`$ pkg install curl`

`$ pkg install git`

`$ git clone https://github.com/bayfrs/Getfollw`

`$ cd getfollw`

`$ chmod +x Getfollw.sh`

`$ termux-wake-lock`

`$ bash Getfollw.sh`

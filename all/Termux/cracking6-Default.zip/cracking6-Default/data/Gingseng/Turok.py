Asu loo
Bosok matamu

Tinggal pake doang dek
Astaga asu


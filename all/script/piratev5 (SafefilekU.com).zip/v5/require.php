<?php 

   $setSpin = "a__whe11l.php";
   $setUJD = "uidgg";
   $setTXM = "txmm";
